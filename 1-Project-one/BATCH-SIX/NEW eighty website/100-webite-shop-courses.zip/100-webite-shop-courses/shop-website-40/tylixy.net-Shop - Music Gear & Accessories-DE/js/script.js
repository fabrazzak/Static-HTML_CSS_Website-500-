
// Mobile Menu Toggle
// Mobile Menu Toggle
const mobileMenuBtn = document.getElementById("mobileMenuBtn");
const mainNav = document.getElementById("mainNav");

mobileMenuBtn.addEventListener("click", () => {
  mainNav.classList.toggle("active");
});

// Close mobile menu when clicking on a link
const navLinks = document.querySelectorAll("nav ul li a");
navLinks.forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("active");
  });
});

// Cart Functionality with localStorage
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// DOM Elements
const cartIcon = document.getElementById("cartIcon");
const cartModal = document.getElementById("cartModal");
const closeCartModal = document.getElementById("closeCartModal");
const cartItemsContainer = document.getElementById("cartItems");
const cartSubtotal = document.getElementById("cartSubtotal");
const cartTotal = document.getElementById("cartTotal");
const cartCount = document.getElementById("cartCount");
const addToCartButtons = document.querySelectorAll(".add-to-cart");
const checkoutBtn = document.getElementById("checkoutBtn");
const checkoutModal = document.getElementById("checkoutModal");
const closeCheckoutModal = document.getElementById("closeCheckoutModal");
const checkoutForm = document.getElementById("checkoutForm");
const confirmationModal = document.getElementById("confirmationModal");
const continueShoppingBtn = document.getElementById("continueShoppingBtn");

// Blog Elements
const blogReadMoreButtons = document.querySelectorAll('.btn-outline');

// Blog Data
const blogPosts = [
  {
    id: 1,
    title: "Top 10 Essential Gear for Live Performances",
    date: "Jan 15, 2025",
    image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    content: `
      <h3>Top 10 Essential Gear for Live Performances</h3>
      <p>When preparing for a live performance, having the right gear can make all the difference between a good show and a great one. Here are the top 10 essential pieces of equipment every performing musician should consider:</p>
      <ol>
        <li><strong>Reliable Instrument:</strong> Whether it's a guitar, keyboard, or drum set, make sure your primary instrument is in top condition.</li>
        <li><strong>Backup Cables:</strong> Always carry extra instrument and microphone cables - they're the most common point of failure.</li>
        <li><strong>Quality Microphone:</strong> A good vocal mic like the Shure SM58 can withstand the rigors of touring.</li>
        <li><strong>In-Ear Monitors:</strong> Protect your hearing and hear yourself clearly with custom in-ear monitors.</li>
        <li><strong>Sturdy Stands:</strong> Invest in heavy-duty stands that won't wobble or collapse during energetic performances.</li>
        <li><strong>Power Conditioner:</strong> Protect your gear from power surges and ensure clean electricity.</li>
        <li><strong>Multi-Tool:</strong> A compact tool that can handle quick repairs and adjustments on the fly.</li>
        <li><strong>Setlist App or Clipboard:</strong> Keep track of your performance order and notes.</li>
        <li><strong>Portable Tuner:</strong> Essential for keeping all instruments in perfect pitch between songs.</li>
        <li><strong>Emergency Kit:</strong> Include spare strings, picks, batteries, duct tape, and other small essentials.</li>
      </ol>
      <p>Remember, the key to a successful performance isn't just talent - it's preparation. Test all your gear before the show and always have backup plans for critical components.</p>
    `
  },
  {
    id: 2,
    title: "How to Choose Your First Drum Set",
    date: "March 28, 2025",
    image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    content: `
      <h3>How to Choose Your First Drum Set</h3>
      <p>Selecting your first drum set can be overwhelming with so many options available. Here's a comprehensive guide to help you make the right choice:</p>
      
      <h4>1. Determine Your Budget</h4>
      <p>Drum sets range from a few hundred to several thousand dollars. As a beginner, aim for the $500-$1000 range for a quality set that will last.</p>
      
      <h4>2. Choose Between Acoustic and Electronic</h4>
      <p><strong>Acoustic drums</strong> offer authentic feel and sound but are loud and require space. <strong>Electronic kits</strong> are quiet with headphones, compact, and offer built-in sounds, but lack the physical response of real drums.</p>
      
      <h4>3. Shell Composition Matters</h4>
      <p>Entry-level drums typically have poplar or basswood shells, while intermediate kits use birch or maple for better tone.</p>
      
      <h4>4. Hardware Quality</h4>
      <p>Check the sturdiness of stands, pedals, and mounts. Weak hardware won't withstand regular playing.</p>
      
      <h4>5. Cymbal Considerations</h4>
      <p>Many starter kits include basic cymbals, but upgrading to professional cymbals makes a huge difference in sound.</p>
      
      <h4>6. Configuration Options</h4>
      <p>Standard 5-piece sets (bass, snare, 3 toms) are versatile for most styles. Consider space limitations if you're in a small apartment.</p>
      
      <h4>7. Brand Reputation</h4>
      <p>Stick with reputable brands like Pearl, Yamaha, Tama, or Ludwig for your first kit - they offer reliable beginner packages.</p>
      
      <p>Remember, your first drum set doesn't need to be perfect. As you develop your skills, you'll learn what features matter most to you for future upgrades.</p>
    `
  },
  {
    id: 3,
    title: "Building a Home Studio on a Budget",
    date: "April 10, 2025",
    image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
    content: `
      <h3>Building a Home Studio on a Budget</h3>
      <p>Creating a professional-quality home recording setup doesn't require breaking the bank. Here's how to build an effective home studio for under $1000:</p>
      
      <h4>Essential Components</h4>
      <ul>
        <li><strong>Computer:</strong> Any relatively modern computer (even a laptop) with at least 8GB RAM will work for basic recording.</li>
        <li><strong>DAW Software:</strong> Start with free options like GarageBand (Mac) or Cakewalk (Windows), or affordable options like Reaper ($60).</li>
        <li><strong>Audio Interface:</strong> The Focusrite Scarlett Solo ($120) provides excellent quality for the price.</li>
        <li><strong>Microphone:</strong> An Audio-Technica AT2020 ($100) is a great starter condenser mic for vocals and instruments.</li>
        <li><strong>Headphones:</strong> Closed-back headphones like the Audio-Technica ATH-M30x ($70) for accurate monitoring.</li>
        <li><strong>Monitors (optional):</strong> If you have extra budget, consider entry-level studio monitors like the PreSonus Eris 3.5 ($100 pair).</li>
      </ul>
      
      <h4>Room Treatment</h4>
      <p>Before spending on gear, optimize your recording space:</p>
      <ul>
        <li>Record in a small, carpeted room with lots of soft furnishings to reduce reflections</li>
        <li>Use DIY acoustic panels made from rockwool insulation ($50 for materials)</li>
        <li>Position your desk in the center of the room, not against a wall</li>
      </ul>
      
      <h4>Smart Upgrades</h4>
      <p>When you're ready to expand, prioritize these upgrades:</p>
      <ol>
        <li>Better microphone (upgrade to $200-$300 range)</li>
        <li>MIDI controller for virtual instruments</li>
        <li>More advanced DAW (like Ableton Live or Pro Tools)</li>
        <li>Additional plugins for mixing/mastering</li>
      </ol>
      
      <p>Remember, the most important factor is your skills, not your gear. Many hit records have been made with equipment less sophisticated than what you can buy today for a few hundred dollars.</p>
    `
  }
];

// Create Blog Modal
const blogModal = document.createElement('div');
blogModal.className = 'modal';
blogModal.id = 'blogModal';
blogModal.innerHTML = `
  <div class="modal-content" style="max-width: 800px;">
    <div class="modal-header">
      <h3 class="modal-title">Blog Post</h3>
      <button class="close-btn" id="closeBlogModal">&times;</button>
    </div>
    <div class="modal-body" id="blogModalContent" style="padding: 30px;">
      <!-- Blog content will be inserted here -->
    </div>
  </div>
`;
document.body.appendChild(blogModal);
const closeBlogModal = document.getElementById('closeBlogModal');

// Blog Modal Functions
function openBlogModal(blogId) {
  const blog = blogPosts.find(post => post.id === blogId);
  if (blog) {
    document.getElementById('blogModalContent').innerHTML = `
      <div class="blog-detail">
        <img src="${blog.image}" alt="${blog.title}" style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;">
        <p style="color: #777; margin-bottom: 15px;">${blog.date}</p>
        ${blog.content}
      </div>
    `;
    blogModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }
}

closeBlogModal.addEventListener('click', () => {
  blogModal.style.display = 'none';
  document.body.style.overflow = 'auto';
});

window.addEventListener('click', (e) => {
  if (e.target === blogModal) {
    blogModal.style.display = 'none';
    document.body.style.overflow = 'auto';
  }
});

// Add event listeners to blog read more buttons
blogReadMoreButtons.forEach((button, index) => {
  button.addEventListener('click', (e) => {
    e.preventDefault();
    openBlogModal(index + 1); // IDs start at 1
  });
});

// Open Cart Modal
cartIcon.addEventListener("click", () => {
  cartModal.style.display = "flex";
  document.body.style.overflow = "hidden";
});

// Close Cart Modal
closeCartModal.addEventListener("click", () => {
  cartModal.style.display = "none";
  document.body.style.overflow = "auto";
});

// Close modal when clicking outside
window.addEventListener("click", (e) => {
  if (e.target === cartModal) {
    cartModal.style.display = "none";
    document.body.style.overflow = "auto";
  }
  if (e.target === checkoutModal) {
    checkoutModal.style.display = "none";
    document.body.style.overflow = "auto";
  }
  if (e.target === confirmationModal) {
    confirmationModal.style.display = "none";
    document.body.style.overflow = "auto";
  }
});

// Add to Cart
addToCartButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const id = button.getAttribute("data-id");
    const name = button.getAttribute("data-name");
    const price = parseFloat(button.getAttribute("data-price"));
    const image = button.getAttribute("data-image");

    // Check if item already in cart
    const existingItem = cart.find((item) => item.id === id);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        id,
        name,
        price,
        image,
        quantity: 1,
      });
    }

    // Save to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    updateCart();
    cartModal.style.display = "flex";
    document.body.style.overflow = "hidden";

    // Add animation to cart icon
    cartIcon.classList.add("animate");
    setTimeout(() => {
      cartIcon.classList.remove("animate");
    }, 500);
  });
});

// Update Cart
function updateCart() {
  // Update cart count
  const totalItems = cart.reduce(
    (total, item) => total + item.quantity,
    0
  );
  cartCount.textContent = totalItems;

  // Update cart items display
  if (cart.length === 0) {
    cartItemsContainer.innerHTML =
      '<p class="empty-cart-message">Your cart is empty</p>';
    cartSummary.style.display = "none";
  } else {
    cartItemsContainer.innerHTML = "";
    cartSummary.style.display = "block";

    cart.forEach((item) => {
      const cartItemElement = document.createElement("div");
      cartItemElement.className = "cart-item";
      cartItemElement.innerHTML = `
                  <img src="${item.image}" alt="${
        item.name
      }" class="cart-item-img">
                  <div class="cart-item-details">
                      <h4 class="cart-item-title">${item.name}</h4>
                      <p class="cart-item-price">$${item.price.toFixed(
                        2
                      )}</p>
                  </div>
                  <div class="cart-item-quantity">
                      <button class="quantity-btn decrease" data-id="${
                        item.id
                      }">-</button>
                      <span>${item.quantity}</span>
                      <button class="quantity-btn increase" data-id="${
                        item.id
                      }">+</button>
                  </div>
                  <button class="remove-item" data-id="${
                    item.id
                  }"><i class="fas fa-times"></i></button>
              `;
      cartItemsContainer.appendChild(cartItemElement);
    });

    // Add event listeners to quantity buttons
    document.querySelectorAll(".decrease").forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.getAttribute("data-id");
        const item = cart.find((item) => item.id === id);

        if (item.quantity > 1) {
          item.quantity -= 1;
        } else {
          cart = cart.filter((item) => item.id !== id);
        }

        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));
        
        updateCart();
      });
    });

    document.querySelectorAll(".increase").forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.getAttribute("data-id");
        const item = cart.find((item) => item.id === id);
        item.quantity += 1;
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));
        
        updateCart();
      });
    });

    document.querySelectorAll(".remove-item").forEach((button) => {
      button.addEventListener("click", () => {
        const id = button.getAttribute("data-id");
        cart = cart.filter((item) => item.id !== id);
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));
        
        updateCart();
      });
    });

    // Calculate subtotal and total
    const subtotal = cart.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    );
    cartSubtotal.textContent = `$${subtotal.toFixed(2)}`;
    cartTotal.textContent = `$${subtotal.toFixed(2)}`;
  }
}

// Proceed to Checkout
checkoutBtn.addEventListener("click", () => {
  cartModal.style.display = "none";
  checkoutModal.style.display = "flex";
});

// Close Checkout Modal
closeCheckoutModal.addEventListener("click", () => {
  checkoutModal.style.display = "none";
  document.body.style.overflow = "auto";
});

// Submit Checkout Form
checkoutForm.addEventListener("submit", (e) => {
  e.preventDefault();

  // In a real application, you would send this data to your server
  console.log("Order submitted:", {
    customer: {
      name: document.getElementById("checkoutName").value,
      email: document.getElementById("checkoutEmail").value,
      phone: document.getElementById("checkoutPhone").value,
      address: document.getElementById("checkoutAddress").value,
    },
    items: cart,
    total: cart.reduce(
      (total, item) => total + item.price * item.quantity,
      0
    ),
  });

  // Show confirmation
  checkoutModal.style.display = "none";
  confirmationModal.style.display = "flex";

  // Clear cart
  cart = [];
  localStorage.removeItem('cart');
  updateCart();
});

// Continue Shopping
continueShoppingBtn.addEventListener("click", () => {
  confirmationModal.style.display = "none";
  document.body.style.overflow = "auto";
  window.location.href = "/shop/";
});

// Initialize cart on page load
updateCart();
